if(!localStorage.getItem('config')) {
    localStorage.setItem('config', '{}');
}

var socket = io();

window.electronAPI = {
    copy: function(text) {
        alert(text); // fix for http
    },
    writeLog: function() {
        // nothing
    },
    recieveConfig: function(callback) {
        electronAPI.recieveConfig_callback = callback;
        electronAPI.getConfig();
    },
    recieveConfig_callback: function() {},
    socketReceive_callback: function() {},
    getConfig: function() {
        electronAPI.recieveConfig_callback(JSON.parse(localStorage.getItem('config')));
    },
    writeConfig: function(config) {
        localStorage.setItem('config', JSON.stringify(config));
    },
    socketReceive: function(callback) {
        electronAPI.socketReceive_callback = callback;
    },
    socketEmit: function() {
        socket.emit(...arguments);
    }
}


// socket.io connect + tb events
var events = ["connect", "update history", "update users", "user joined", "user left", "user change nick", "message", "cmd"];

for(var i = 0; i < events.length; i++) {
    (function() {
        var evt = events[i]
        socket.on(evt, function(data) {
            electronAPI.socketReceive_callback({name: evt, data}); // forward the event
        })
    })()
}

socket.on('connect_error', function(data) {
    electronAPI.socketReceive_callback({name: 'connect_error', data});
    if(!socket.active) {
        console.error('Socket is not active, reconnecting...')
        socket.connect();
    }
})

socket.on('disconnect', function(reason) {
    electronAPI.socketReceive_callback({name: 'disconect', data: reason});
    if(!socket.active) {
        console.error('Socket disconnected:', reason);
        socket.connect();
    }
})

var script = document.createElement('script');
script.src = '/index.js';
script.type = 'module';
document.body.appendChild(script);